<?php

function http_request($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

$data = http_request("http://localhost/pbw2/Pertemuan%207/test/showMhs");
$data = json_decode($data, TRUE); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>PBW2 - Pertemuan 6</title>
    <link rel="stylesheet" type="text/css" href="assets\css\bootstrap\bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets\css\style.css">
</head>
<body>
    <div class="container" id="kontener">
        <div class="bg-primary text-center p-4" id="header">
            <h3>Pemrograman Berbasis Web 2</h3>
        </div>
        <div id="konten">
            <h3>Data Mahasiswa</h3> <a href="tambah.php" class="btn btn-primary w-25">Tambah Data</a>
            <table class="table table-striped">
                <thead>
                    <th>NO</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Fakultas</th>
                    <th>Program Studi</th>
                    <th>Aksi</th>
                </thead>
                <?php  
                    $i = 1;
                    foreach ($data as $data) {
                    ?>
                    <form method="GET" action="showMhs">
                    <tr>
                        <td>
                            <?= $i++ ?>
                        </td>
                        <td>
                            <?= $data["nim"] ?>
                        </td>
                        <td>
                            <?= $data["nama"] ?>
                        </td>
                        <td>
                            <?= $data["kelas"] ?>
                        </td>
                        <td>
                            <?= $data["fakultas"] ?>
                        </td>
                        <td>
                            <?= $data["prodi"] ?>
                        </td>
                        <td colspan="2"> 
                            <a href="../Pertemuan 7/test/edit.php?id=<?= $data['id'] ?>" class="btn btn-primary">Edit</a> 
                            <input type="hidden" name="id" value="<?= $data['id'] ?>">
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-danger">Hapus</button> 
                        </td>
                    </tr>
                    </form>
                    <?php } ?>
            </table>
        </div>
        <div class="bg-primary text-center p-2" id="footer">
            <h4>Tahun Ajaran 2025 - 2026</h4>
        </div>
    </div>
</body>
</html>


