import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HeadTitle from './component/HeadTitle';
import HeadNav from './component/HeadNav';
import Home from './component/Home';
import About from './component/About';
import Footer from './component/Footer';
import './App.css';

function App() {
  return (
    <BrowserRouter>
    <div class="grid-container">
      <HeadTitle/>
      <HeadNav/>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
      </Routes>
      <Footer/>
    </div>
    </BrowserRouter>
  );
}

export default App;
