
    import '../App.css'; 

    function Footer() {
      return (
        <div class="item5"><p>Semester Genap Tahun Ajaran 2024-2025</p></div>
      );
    }

    export default Footer;