
    import '../App.css'; 

    function HeadTitle() {
      return (
        <div class="item1"><h1>Pemrograman Berbasis Web 1</h1></div>
      );
    }

    export default HeadTitle;