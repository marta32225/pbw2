
    import '../App.css'; 

    function Home() {
      return (
        <div class="item3">
                <h1>Pokok Materi</h1>
                <ol>
                    <li>Web Development</li>
                    <li>HTML</li>
                    <li>CSS</li>
                    <li>Javascript</li>
                </ol>
        </div>
      );
    }

    export default Home;