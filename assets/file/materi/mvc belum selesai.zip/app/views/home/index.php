<!DOCTYPE html>
<html>
<head>
	<title>Halaman Home</title>
</head>
<body>
	<h3>Selamat datang di home/index dari controller home/index</h3>
</body>
</html>