<?php
/**
* 
*/
class Home extends Controller
{
	
	public function index()
	{
		# code...
		$this->view("home/index");
	}
}