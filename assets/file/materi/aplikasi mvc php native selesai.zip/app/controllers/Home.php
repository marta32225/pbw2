<?php

/**
* 
*/
class Home extends Controller
{
	
	public function index()
	{
		# code...
		$this->view('home/index');
	}
	public function id($nama='Taufiq',$usia=33)
	{
		# code...
		$data['nama'] = $nama;
		$data['usia'] = $usia; 
		$this->view('home/id',$data);
	}
	public function template()
	{
		# code...
		$data['title'] = 'Template';
		$this->view('template/header',$data);
		$this->view('home/template');
		$this->view('template/footer');		
	}
	public function dataModel()
	{
		# code...
		$data['title'] = 'Model';
		$data['nama']  = $this->model('userModel')->getUser();
		$this->view('template/header',$data);
		$this->view('home/modelView',$data);
		$this->view('template/footer');	
	}
	public function dbModel()
	{
		# code...
		$data['title'] = 'Model';
		$data['produk']  = $this->model('userModel')->getProduk();
		$this->view('template/header',$data);
		$this->view('home/produkView',$data);
		$this->view('template/footer');	
	}
	public function detail($id)
	{
		# code...
		$data['title'] = 'Model View';
		$data['produk']  = $this->model('userModel')->getProdukByID($id);
		$this->view('template/header',$data);
		$this->view('home/produkDetail',$data);
		$this->view('template/footer');	
	}
	public function addProduk()
	{
		# code...
		$data['title'] = 'Model View Tambah Produk';
		$this->view('template/header',$data);
		$this->view('home/tambahData');
		$this->view('template/footer');	
	}
	public function simpanTambah()
	{
		# code...
		if ($this->model('userModel')->tambahDataProduk($_POST) > 0) {
			# code...
			Flasher::setFlash('Berhasil','ditambahkan');
			header('location:' . BASEURL . '/Home/dbModel');
			exit;
		}else{
			Flasher::setFlash('Gagal','ditambahkan');
			header('location:' . BASEURL . '/Home/dbModel');
			exit;
		}
	}
	public function editProduk($id)
	{
		# code...
		$data['title'] = 'Model View Edit Produk';
		$data['produk']  = $this->model('userModel')->getProdukByID($id);
		$this->view('template/header',$data);
		$this->view('home/formEditProduk',$data);
		$this->view('template/footer');	
	}
	public function simpanEdit()
	{
		# code...
		if ($this->model('userModel')->simpanEditProduk($_POST) > 0) {
			# code...
			Flasher::setFlash('Berhasil','simpan Edit');
			header('location:' . BASEURL . '/Home/dbModel');
			exit;
		}else{
			Flasher::setFlash('Gagal','simpan Edit');
			header('location:' . BASEURL . '/Home/dbModel');
			exit;
		}
	}
	public function deleteProduk($id)
	{
		# code...
		if ($this->model('userModel')->hapusProduk($id) > 0) {
			# code...
			Flasher::setFlash('Berhasil','dihapus');
			header('location:' . BASEURL . '/Home/dbModel');
			exit;
		}else{
			Flasher::setFlash('Gagal','dihapus');
			header('location:' . BASEURL . '/Home/dbModel');
			exit;
		}
	}
}