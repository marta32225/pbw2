<?php

/**
* 
*/
class userModel 
{

	private $table = 'produk';
	private $db;

	public function __construct()
	{
		# code...
		$this->db = new Database();
	}

	private $nama = 'Taufiq';
	function getUser()
	{
		# code...
		return $this->nama;
	}
	public function getProduk()
	{
		# code...
		$this->db->query('SELECT * FROM ' . $this->table);
		return $this->db->resultSet();
	}
	public function getProdukByID($id)
	{
		# code...
		$this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
		$this->db->bind('id',$id);
		return $this->db->single();
	}
	public function tambahDataProduk($data)
	{
		# code...
		$query = "INSERT INTO produk VALUES ('',:nama,:tipe,:harga,:stok)";
		$this->db->query($query);
		$this->db->bind('nama',$data['nama_produk']);
		$this->db->bind('tipe',$data['tipe_produk']);
		$this->db->bind('harga',$data['harga']);
		$this->db->bind('stok',$data['stok']);
		$this->db->execute();
		return $this->db->rowCount();
	}
	public function simpanEditProduk($data)
	{
		# code...
		$query = "UPDATE produk SET nama_produk = :nama, tipe_produk = :tipe, harga = :harga, stok = :stok WHERE id = :id";
		$this->db->query($query);
		$this->db->bind('id',$data['id']);
		$this->db->bind('nama',$data['nama_produk']);
		$this->db->bind('tipe',$data['tipe_produk']);
		$this->db->bind('harga',$data['harga']);
		$this->db->bind('stok',$data['stok']);
		$this->db->execute();
		return $this->db->rowCount();
	}
	public function hapusProduk($id)
	{
		# code...
		$query = "DELETE FROM produk WHERE id = :id";
		$this->db->query($query);
		$this->db->bind('id',$id);
		$this->db->execute();
		return $this->db->rowCount();
	}
}