<!DOCTYPE html>
<html>
<head>
	<title>Halaman <?= $data['title'] ?></title>
	<link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>/css/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>/css/style.css">
</head>
<body>