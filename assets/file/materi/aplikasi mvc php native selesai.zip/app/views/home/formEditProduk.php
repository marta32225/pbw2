<div id="kontener">
    <div class="bg-primary text-center p-5" id="header">
        <h2>Pemrograman Berbasis Web 2</h2>
    </div>
    <div id="konten">
        <p>form ini digunakan untuk edit produk</p>
        <form action="<?= BASEURL; ?>/Home/simpanEdit" method="post" id="form">
        <table>
            <tr>
                <td><label for="">Nama Produk</label></td>
                <td>:</td>
                <td><input type="text" name="nama_produk" id="nama_produk" placeholder="Nama Produk" value="<?= $data['produk']['nama_produk'] ?>"> </td>
            </tr>
            <tr>
                <td><label for="">Tipe Produk</label></td>
                <td>:</td>
                <td><input type="text" name="tipe_produk" id="tipe_produk" placeholder="Tipe Produk" value="<?= $data['produk']['tipe_produk'] ?>"></td>
            </tr>
            <tr>
                <td><label for="">Harga</label></td>
                <td>:</td>
                <td><input type="text" name="harga" id="harga" placeholder="Harga" value="<?= $data['produk']['harga'] ?>"> </td>
            </tr>
            <tr>
                <td><label for="">Stok</label></td>
                <td>:</td>
                <td><input type="text" name="stok" id="stok" placeholder="Stok" value="<?= $data['produk']['stok'] ?>"> </td>
            </tr>
            <tr>
                <td colspan="3">
                    <input type="hidden" name="id" id="id" value="<?= $data['produk']['id'] ?>">
                    <button type="submit" class="btn btn-primary" style="width: 145px;">Simpan</button>
                    <a href="<?= BASEURL; ?>/Home/dbModel" class="btn btn-primary" style="width: 145px;">Kembali</a>
                </td>
            </tr>
        </table>
        </form>
    </div>
    <div class="bg-primary text-center p-3" id="footer">
        <h4>Tahun Ajaran 2025-2026</h4>
    </div>
</div>