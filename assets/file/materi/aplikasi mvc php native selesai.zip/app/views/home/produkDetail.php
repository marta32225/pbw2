<div id="kontener">
    <div class="bg-primary text-center p-5" id="header">
        <h2>Pemrograman Berbasis Web 2</h2>
    </div>
    <div id="konten">
        <table>
			<tr>
				<td>Nama Produk</td>
				<td>:</td>
				<td><?= $data['produk']['nama_produk'] ?></td>
			</tr>
			<tr>
				<td>Tipe Produk</td>
				<td>:</td>
				<td><?= $data['produk']['tipe_produk'] ?></td>
			</tr>
			<tr>
				<td>Harga</td>
				<td>:</td>
				<td><?= $data['produk']['harga'] ?></td>
			</tr>
			<tr>
				<td>Stok</td>
				<td>:</td>
				<td><?= $data['produk']['stok'] ?></td>
			</tr>
			<tr>
				<td colspan="3">
					<a href="<?= BASEURL; ?>/Home/dbModel" class="btn btn-primary">Kembali</a>
				</td>
			</tr>
		</table>
    </div>
    <div class="bg-primary text-center p-3" id="footer">
        <h4>Tahun Ajaran 2025-2026</h4>
    </div>
</div>