<div id="kontener">
    <div class="bg-primary text-center p-5" id="header">
        <h2>Pemrograman Berbasis Web 2</h2>
    </div>
    <div id="konten">
        <p>form ini digunakan untuk tambah data produk</p>
        <form action="<?= BASEURL; ?>/Home/simpanTambah" method="post" id="form">
        <table>
            <tr>
                <td><label for="">Nama Produk</label></td>
                <td>:</td>
                <td><input type="text" name="nama_produk" id="nama_produk" placeholder="Nama Produk" aria-describedby="helpId"> </td>
            </tr>
            <tr>
                <td><label for="">Tipe Produk</label></td>
                <td>:</td>
                <td><input type="text" name="tipe_produk" id="tipe_produk" placeholder="Tipe Produk" aria-describedby="helpId"></td>
            </tr>
            <tr>
                <td><label for="">Harga</label></td>
                <td>:</td>
                <td><input type="text" name="harga" id="harga" placeholder="Harga" aria-describedby="helpId"> </td>
            </tr>
            <tr>
                <td><label for="">Stok</label></td>
                <td>:</td>
                <td><input type="text" name="stok" id="stok" placeholder="Stok" aria-describedby="helpId"> </td>
            </tr>
            <tr>
                <td colspan="3">
                    <button type="submit" class="btn btn-primary mt-1 mb-1" style="width: 145px;">Simpan</button>
                    <a href="<?= BASEURL; ?>/Home/dbModel" class="btn btn-primary mt-1 mb-1" style="width: 145px;">Kembali</a>
                </td>
            </tr>
        </table>
        </form>
    </div>
    <div class="bg-primary text-center p-3" id="footer">
        <h4>Tahun Ajaran 2025-2026</h4>
    </div>
</div>