<div class="container">
	<div class="row bg-primary text-center p-5" >
		<h2>Pemrograman Berbasis Web 2</h2>
	</div>
	<div class="row">
		<script type="text/javascript">
		<?php
			echo	Flasher::flash();
			session_destroy();
		?>
		</script>
		<a href="<?= BASEURL; ?>/Home/addProduk" class="btn btn-primary mt-1 mb-1 w-25">Tambah Data</a>
		<table class="table bordered table-striped table-hover">
			<thead>
				<th>No</th>
				<th>Nama Produk</th>
				<th>Tipe Produk</th>
				<th>Aksi</th>
			</thead>
			<tbody>
				<?php  
                	$i = 1;
                	foreach ($data['produk'] as $data) {
                	?>
                	<tr>
                    	<td>
                        	<?= $i++ ?>
                    	</td>
                    	<td>
                        	<?= $data["nama_produk"] ?>
                    	</td>
                    	<td>
                        	<?= $data["tipe_produk"] ?>
                    	</td>
                    	<td>
                        	<a href="<?= BASEURL; ?>/Home/detail/<?= $data['id'] ?>" class="btn btn-info">Detail</a>
                        	<a href="<?= BASEURL; ?>/Home/editProduk/<?= $data['id'] ?>" class="btn btn-primary">Edit</a>
                        	<a href="<?= BASEURL; ?>/Home/deleteProduk/<?= $data['id'] ?>" onclick="return confirm('Yakin Nama Produk <?= $data["nama_produk"] ?> akan dihapus?');" class="btn btn-danger">Hapus</a>
                    	</td>
                	</tr>
            	<?php } ?>
			</tbody>
		</table>
	</div>
	<div class="row bg-primary text-center p-3">
		<h4>Tahun Ajaran 2025-2026</h4>
	</div>
</div>