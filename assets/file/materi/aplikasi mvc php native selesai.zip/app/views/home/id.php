<!DOCTYPE html>
<html>
<head>
	<title>Halaman ID</title>
</head>
<body>
	<h3>Selamat datang di praktikum view, <?= $data['nama'] ?></h3>
</body>
</html>