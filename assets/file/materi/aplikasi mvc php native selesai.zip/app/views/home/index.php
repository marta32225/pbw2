<!DOCTYPE html>
<html>
<head>
	<title>Halaman Home</title>
</head>
<body>
	<h3>Selamat datang di praktikum view</h3>
</body>
</html>