<?php

/**
* 
*/
class Database
{
	private $host = DBHOST;
	private $user = DBUSER;
	private $pass = DBPASS;
	private $dbName = DBNAME;

	private $dbh;
	private $stmt;

	public function __construct()
	{
		# code...
		$dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->dbName;
		$option = [
			PDO::ATTR_PERSISTENT => true,
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
		];
		try {
			$this->dbh = new PDO($dsn,$this->user,$this->pass,$option);
		} catch (PDOException $e) {
			die($e->getMessage());
		}
	}
	
	public function query($query)
	{
		# code...
		$this->stmt = $this->dbh->prepare($query);
	}

	public function bind($param,$value,$type = null)
	{
		# code...
		if (is_null($type)) {
			# code...
			switch (true) {
				case is_int($value):
					# code...
					$type = PDO::PARAM_INT;
					break;

				case is_bool($value):
					# code...
					$type = PDO::PARAM_BOOL;
					break;

				case is_null($value):
					# code...
					$type = PDO::PARAM_NULL;
					break;
				
				default:
					# code...
					$type = PDO::PARAM_STR;
					break;
			}
		}

		$this->stmt->bindValue($param,$value,$type);
	}

	public function execute()
	{
		# code...
		$this->stmt->execute();
	}

	public function resultSet()
	{
		# code...
		$this->execute();
		return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public function single()
	{
		# code...
		$this->execute();
		return $this->stmt->fetch(PDO::FETCH_ASSOC);
	}
	public function rowCount()
	{
		# code...
		return $this->stmt->rowCount();
	}
}