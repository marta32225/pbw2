<?php

/**
* 
*/
class Flasher
{
	
	public static function setFlash($pesan,$aksi,$tipe = none)
	{
		# code...
		$_SESSION['flashh'] = [
			'pesan'	=> $pesan,
			'aksi'	=> $aksi,
			'tipe'	=> $tipe
		];
	}

	public static function flash()
	{
		# code...
		if (isset($_SESSION['flashh'])) {
			# code...
			echo "alert('Data produk ".$_SESSION['flashh']['pesan']." ".$_SESSION['flashh']['aksi']."');";
			unset($_SESSION['flash']);
		}
	}
}