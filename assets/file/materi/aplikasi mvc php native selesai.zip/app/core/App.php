<?php

/**
* 
*/
class App 
{
	protected $controller 	= 'Home';
	protected $method		= 'index';
	protected $params		= [];

	public function __construct()
	{
		# code...
		$url = $this->parseURL();
		if (!empty($url)) {
			# code...
			if(file_exists('../app/controllers/' . $url[0] . '.php') ){
				$this->controller = $url[0];
				unset($url[0]);
			}
			require_once '../app/controllers/' . $this->controller . '.php';
		}
		require_once '../app/controllers/' . $this->controller . '.php';
		$this->controller = new $this->controller;

		if (isset($url[1])) {
			# code...
			if (method_exists($this->controller, $url[1])) {
				# code...
				$this->method = $url[1];
				unset($url[1]);
			}
		}

		if (!empty($url)) {
			# code...
			$this->params = array_values($url);
		}

		call_user_func_array([$this->controller,$this->method], $this->params);
	}
	public function parseURL()
	{
		# code...
		if (isset($_GET['url'])) {
			# code...
			$url = rtrim($_GET['url'],'/');
			$url = filter_var($url,FILTER_SANITIZE_URL);
			$url = explode('/', $url);
			return $url;
		}
	}
}