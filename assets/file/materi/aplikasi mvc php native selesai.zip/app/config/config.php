<?php

define('BASEURL', 'http://localhost/pbw2/Pertemuan%208/public');

// DB

define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBPASS', '');
define('DBNAME', 'dbrest');