<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head><title>Tambah Mahasiswa</title></head>
<body>
    <h2>Tambah Data Mahasiswa</h2>
    <form method="POST">
        Nama: <input type="text" name="nama"><br>
        Jurusan: <input type="text" name="jurusan"><br>
        <input type="submit" name="submit" value="Simpan">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $nama = $_POST['nama'];
        $jurusan = $_POST['jurusan'];
        mysqli_query($conn, "INSERT INTO mahasiswa (nama, jurusan) VALUES ('$nama', '$jurusan')");
        header("Location: index.php");
    }
    ?>
</body>
</html>