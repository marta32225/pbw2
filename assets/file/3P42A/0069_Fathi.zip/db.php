<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "uji";

$conn = mysqli_connect($host, $user, $pass, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>