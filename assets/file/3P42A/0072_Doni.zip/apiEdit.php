<?php
include "koneksi.php";

$nim     = $_POST['nim'];
$nama    = $_POST['nama'];
$jurusan = $_POST['jurusan'];

$update = mysqli_query(
    $koneksi,
    "UPDATE mahasiswa SET 
        nama = '$nama', 
        jurusan = '$jurusan'
     WHERE nim = '$nim'"
);

echo json_encode([
    "status"  => $update ? true : false,
    "message" => $update ? "Data berhasil diupdate" : "Gagal update data"
]);
?>
