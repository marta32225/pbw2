<?php
include "koneksi.php";

$nim = $_POST['nim'];

$hapus = mysqli_query($koneksi, "DELETE FROM mahasiswa WHERE nim = '$nim'");

echo json_encode([
    "status"  => $hapus ? true : false,
    "message" => $hapus ? "Data berhasil dihapus" : "Gagal menghapus"
]);
?>
