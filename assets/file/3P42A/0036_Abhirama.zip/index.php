<?php
$koneksi = new mysqli("localhost", "root", "", "bukudata");

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

if (isset($_POST['tambah'])) {
    $isbn = $_POST['isbn'];
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $kategori = $_POST['kategori'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $koneksi->query("INSERT INTO buku (isbn, judul, penulis, kategori, harga, stok)
                     VALUES ('$isbn','$judul','$penulis','$kategori','$harga','$stok')");
    header("Location: index.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $koneksi->query("DELETE FROM buku WHERE id=$id");
    header("Location: index.php");
    exit;
}

if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $isbn = $_POST['isbn'];
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $kategori = $_POST['kategori'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $koneksi->query("UPDATE buku SET 
        isbn='$isbn', judul='$judul', penulis='$penulis', kategori='$kategori',
        harga='$harga', stok='$stok' WHERE id=$id");
    header("Location: index.php");
    exit;
}

$data = $koneksi->query("SELECT * FROM buku ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Katalog Buku (CRUD)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h3 class="text-center text-primary mb-4">Katalog Buku (CRUD Sederhana)</h3>

    <div class="card mb-4">
        <div class="card-header bg-success text-white">Tambah Buku</div>
        <div class="card-body">
            <form method="post">
                <div class="row g-2">
                    <div class="col-md-2"><input type="text" name="isbn" class="form-control" placeholder="ISBN" required></div>
                    <div class="col-md-2"><input type="text" name="judul" class="form-control" placeholder="Judul" required></div>
                    <div class="col-md-2"><input type="text" name="penulis" class="form-control" placeholder="Penulis" required></div>
                    <div class="col-md-2"><input type="text" name="kategori" class="form-control" placeholder="Kategori" required></div>
                    <div class="col-md-2"><input type="number" name="harga" class="form-control" placeholder="Harga" required></div>
                    <div class="col-md-1"><input type="number" name="stok" class="form-control" placeholder="Stok" required></div>
                    <div class="col-md-1 d-grid"><button class="btn btn-success" name="tambah">Tambah</button></div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-primary text-white">Daftar Buku</div>
        <div class="card-body">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark text-center">
                    <tr>
                        <th>No</th>
                        <th>ISBN</th>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
            <?php 
            $no = 1;
            while($row = $data->fetch_assoc()): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($row['isbn']); ?></td>
                    <td><?= htmlspecialchars($row['judul']); ?></td>
                    <td><?= htmlspecialchars($row['penulis']); ?></td>
                    <td><?= htmlspecialchars($row['kategori']); ?></td>
                    <td><?= number_format($row['harga'], 0, ',', '.'); ?></td>
                    <td><?= $row['stok']; ?></td>
                    <td class="text-center">
                        <a href="?edit_id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="?hapus=<?= $row['id']; ?>" class="btn btn-danger btn-sm"
                        onclick="return confirm('Hapus buku ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
            </table>
        </div>
    </div>

    <?php if(isset($_GET['edit_id'])):
        $id = $_GET['edit_id'];
        $edit = $koneksi->query("SELECT * FROM buku WHERE id=$id")->fetch_assoc();
    ?>
    <div class="card mt-4">
        <div class="card-header bg-warning">Edit Buku</div>
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="id" value="<?= $edit['id']; ?>">
                <div class="row g-2">
                    <div class="col-md-2"><input type="text" name="id" class="form-control" value="<?= $edit['isbn']; ?>"></div>
                    <div class="col-md-2"><input type="text" name="judul" class="form-control" value="<?= $edit['judul_buku']; ?>"></div>
                    <div class="col-md-2"><input type="text" name="pengarang" class="form-control" value="<?= $edit['penulis']; ?>"></div>
                    <div class="col-md-2"><input type="text" name="kategori" class="form-control" value="<?= $edit['kategori']; ?>"></div>
                    <div class="col-md-2"><input type="number" name="harga" class="form-control" value="<?= $edit['cost']; ?>"></div>
                    <div class="col-md-1"><input type="number" name="stok" class="form-control" value="<?= $edit['stok']; ?>"></div>
                    <div class="col-md-1 d-grid"><button class="btn btn-warning" name="edit">Simpan</button></div>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>
</body>
</html>