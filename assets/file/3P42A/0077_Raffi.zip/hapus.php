<?php
include "config.php";

$nim = $_GET['id'];

mysqli_query($koneksi, "DELETE FROM mahasiswa WHERE noid='$nim'");

echo "
    <script>
        alert('Data Berhasil Dihapus!');
        window.location='index.php';
    </script>
";
?>
