<?php
$conn = mysqli_connect("localhost","root","","db_pegawai");
if(!$koneksi){ echo "Koneksi Database Gagal!"; }
?>