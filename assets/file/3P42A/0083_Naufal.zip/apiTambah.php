<?php
include "koneksi.php";

$nim     = $_POST['nim'];
$nama    = $_POST['nama'];
$jurusan = $_POST['jurusan'];

$insert = mysqli_query($koneksi, "INSERT INTO mahasiswa (nim, nama, jurusan) VALUES ('$nim', '$nama', '$jurusan')");

echo json_encode([
    "status"  => $insert ? true : false,
    "message" => $insert ? "Data berhasil ditambahkan" : "Gagal menambahkan"
]);
?>
