<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
</head>
<body>
    <h2>Daftar Mahasiswa</h2>
    <a href="create.php">Tambah Data</a>
    <table border="1">
        <tr><th>ID</th><th>Nama</th><th>Jurusan</th><th>Aksi</th></tr>
        <?php
        $result = mysqli_query($conn, "SELECT * FROM pegawai");
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['nama']}</td>
                    <td>{$row['prodi']}</td>
                    <td>
                        <a href='edit.php?id={$row['id']}'>Edit</a> |
                        <a href='delete.php?id={$row['id']}'>Hapus</a>
                    </td>
                  </tr>";
        }
        ?>
    </table>
</body>
</html>