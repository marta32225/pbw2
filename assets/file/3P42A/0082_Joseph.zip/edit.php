<?php include 'db.php'; ?>
<?php
$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE id=$id");
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head><title>Edit Mahasiswa</title></head>
<body>
    <h2>Edit Data Mahasiswa</h2>
    <form method="POST">
        Nama: <input type="text" name="nama" value="<?= $row['nama'] ?>"><br>
        Jurusan: <input type="text" name="jurusan" value="<?= $row['jurusan'] ?>"><br>
        <input type="submit" name="submit" value="Update">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $nama = $_POST['nama'];
        $jurusan = $_POST['jurusan'];
        mysqli_query($conn, "UPDATE mahasiswa SET nama='$nama', jurusan='$jurusan' WHERE id=$id");
        header("Location: index.php");
    }
    ?>
</body>
</html>