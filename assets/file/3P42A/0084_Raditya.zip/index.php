<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>CRUD PHP Bootstrap</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="text-center">Data Mahasiswa</h2>

    <a href="tambah.php" class="btn btn-primary mb-3">+ Tambah Data</a>

    <table class="table table-bordered table-striped">
        <tr>
            <th>Nomor</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Jurusan</th>
            <th>Aksi</th>
        </tr>

        <?php
        $data = mysqli_query($koneksi, "SELECT * FROM mahasiswa ORDER BY nomor ASC");
        $no = 1;

        while ($d = mysqli_fetch_array($data)) {
        ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $d['nim']; ?></td>
                <td><?= $d['nama']; ?></td>
                <td><?= $d['jurusan']; ?></td>
                <td>
                    <a href="edit.php?nim=<?= $d['nim']; ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="hapus.php?nim=<?= $d['nim']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data?');">
                        Hapus
                    </a>
                </td>
            </tr>
        <?php } ?>

    </table>
</div>

</body>
</html>
