<?php
include "koneksi.php";

$data   = mysqli_query($koneksi, "SELECT * FROM mahasiswa");
$result = [];

while ($row = mysqli_fetch_assoc($data)) {
    $result[] = $row;
}

echo json_encode([
    "status"  => true,
    "message" => "Data ditemukan",
    "data"    => $result
]);
?>
