<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

require_once __DIR__ . "/../config/db.php";

function output($data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    $stmt = $conn->query("SELECT id, isbn, judul, penulis, kategori, harga, stok FROM buku ORDER BY id ASC");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    output($rows);
} catch (Throwable $e) {
    $dummy = [
        ["id" => 3, "isbn" => "978602032xxx", "judul" => "Algoritma Dasar", "penulis" => "R. Santoso", "kategori" => "Informatika", "harga" => 89000, "stok" => 12],
        ["id" => 2, "isbn" => "978623001xxx", "judul" => "Statistika untuk Pemula", "penulis" => "N. Puspita", "kategori" => "Statistik", "harga" => 76000, "stok" => 7],
        ["id" => 1, "isbn" => "978602040xxx", "judul" => "Ekonomi Makro Ringkas", "penulis" => "A. Pratama", "kategori" => "Ekonomi", "harga" => 99000, "stok" => 3],
    ];
    output($dummy);
}
?>