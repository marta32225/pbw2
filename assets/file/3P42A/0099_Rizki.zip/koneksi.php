<?php
$koneksi = mysqli_connect("localhost","root","","data_mahasiswa");
if(!$koneksi){ echo "Koneksi Database Gagal!"; }
?>