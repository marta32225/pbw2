<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Mahasiswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2>Tambah Data Mahasiswa</h2>

    <form method="post">
        <div class="mb-3">
            <label>NIM</label>
            <input type="text" name="nim" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Jurusan</label>
            <select name="jurusan" class="form-control" required>
                <option value="">-- Pilih Jurusan --</option>
                <option value="Teknik Informatika">Teknik Informatika</option>
                <option value="Sistem Informasi">Sistem Informasi</option>
                <option value="Manajemen Akutansi">Manajemen Akutansi</option>
            </select>
        </div>

        <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>

    <?php
    if (isset($_POST['simpan'])) {
        mysqli_query(
            $koneksi,
            "INSERT INTO mahasiswa (nim, nama, jurusan) VALUES ('".$_POST['nim']."', '".$_POST['nama']."', '".$_POST['jurusan']."')"
        );

        echo "
        <script>
            alert('Data Berhasil Disimpan!');
            window.location='index.php';
        </script>";
    }
    ?>
</div>

</body>
</html>
