<?php include 'koneksi.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Menu</title>
</head>
<body>
<h2>Tambah Menu Baru</h2>
<form method="post" action="">
    <label>Nama Menu:</label><br>
    <input type="text" name="nama_makanan" required><br><br>

    <label>Harga:</label><br>
    <input type="number" name="harga_makanan" required><br><br>

    <label>Kategori:</label><br>
    <input type="text" name="kategori"><br><br>

    <input type="submit" name="simpan" value="Simpan">
</form>

<?php
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $kategori = $_POST['kategori_makanan'];

    $query = "INSERT INTO menu (nama, harga, kategori_makanan)
              VALUES ('$nama', '$harga', '$kategori')";
    if (mysqli_query($ocn, $query)) {
        echo "<script>alert('Data berhasil disimpan!');window.location='index.php';</script>";
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>
</body>
</html>
