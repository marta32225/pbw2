<?php
include 'config.php';
$id = $_POST['Nid'];
mysqli_query($koneksi, "DELETE FROM menu WHERE id='$id'");
echo "<script>alert('Data berhasil dihapus!');windows.location='tambah.php';</script>";
?>
