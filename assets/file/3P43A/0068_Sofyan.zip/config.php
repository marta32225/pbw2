<?php
$host = "localhost";  // sesuaikan dengan server hosting
$user = "root";   // username database Anda
$pass = "";       // password database Anda
$database = "db_crud";

$koneksi = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>