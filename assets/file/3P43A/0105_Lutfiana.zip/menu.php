<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Menu - Snow Coffee Shop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1c1c1c; color: #f5f5f5; font-family: 'Poppins', sans-serif; }
    h1, h2, h5 { color: #d4a373; }
    .navbar { background-color: #2b2b2b; }
    .navbar-brand { color: #d4a373 !important; font-weight: bold; }
    .nav-link { color: #f5f5f5 !important; }
    .nav-link:hover { color: #d4a373 !important; }

    .card { background-color: #2b2b2b; border: none; transition: transform 0.3s; }
    .card:hover { transform: scale(1.03); }
    .btn-beli { background-color: #6f4e37; border: none; color: white; }
    .btn-beli:hover { background-color: #8b5e3c; }

    .nav-pills .nav-link.active { background-color: #6f4e37; color: white; }
    footer { background-color: #2b2b2b; color: #f5f5f5; padding: 20px 0; text-align: center; margin-top: 50px; }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php">☕ Snow Coffee Shop</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link active" href="menu.php">Menu</a></li>
        <li class="nav-item"><a class="nav-link" href="rating.php">Rating</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Daftar Produk -->
<div class="container py-5">
  <h2 class="text-center mb-4">Menu Kami</h2>

  <!-- Tab Menu -->
  <ul class="nav nav-pills justify-content-center mb-4" id="menuTab" role="tablist">
    <li class="nav-item">
      <button class="nav-link active" id="minuman-tab" data-bs-toggle="pill" data-bs-target="#minuman" type="button">Minuman</button>
    </li>
    <li class="nav-item">
      <button class="nav-link" id="makanan-tab" data-bs-toggle="pill" data-bs-target="#makanan" type="button">Makanan</button>
    </li>
  </ul>

  <!-- Konten Tab -->
  <div class="tab-content">
    <!-- Tab Minuman -->
    <div class="tab-pane fade show active" id="minuman" role="tabpanel">
      <div class="row">
        <?php
        $data = mysqli_query($koneksi, "SELECT * FROM produk WHERE kategori='Minuman'");
        while ($d = mysqli_fetch_array($data)) {
        ?>
          <div class="col-md-4 mb-4">
            <div class="card h-100 text-center">
              <img src="img/<?= $d['gambar'] ?>" class="card-img-top" alt="<?= $d['nama_produk'] ?>" style="height:200px; object-fit:cover;">
              <div class="card-body">
                <h5><?= $d['nama_produk'] ?></h5>
                <p>Rp <?= number_format($d['harga'], 0, ',', '.') ?></p>
                <p>Stok: <?= $d['stok'] ?></p>
                <a href="beli.php?id=<?= $d['id_produk'] ?>" class="btn btn-beli">Beli Sekarang</a>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>

    <!-- Tab Makanan -->
    <div class="tab-pane fade" id="makanan" role="tabpanel">
      <div class="row">
        <?php
        $data = mysqli_query($koneksi, "SELECT * FROM produk WHERE kategori='Makanan'");
        while ($d = mysqli_fetch_array($data)) {
        ?>
          <div class="col-md-4 mb-4">
            <div class="card h-100 text-center">
              <img src="img/<?= $d['gambar'] ?>" class="card-img-top" alt="<?= $d['nama_produk'] ?>" style="height:200px; object-fit:cover;">
              <div class="card-body">
                <h5><?= $d['nama_produk'] ?></h5>
                <p>Rp <?= number_format($d['harga'], 0, ',', '.') ?></p>
                <p>Stok: <?= $d['stok'] ?></p>
                <a href="beli.php?id=<?= $d['id_produk'] ?>" class="btn btn-beli">Beli Sekarang</a>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
<footer>
  <p>© 2025 Snow Coffee Shop | Dibuat dengan ☕ dan cinta</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
