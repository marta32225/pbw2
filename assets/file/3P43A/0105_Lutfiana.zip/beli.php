<?php
include 'koneksi.php';
$id = $_GET['id'];
$q = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk='$id'");
$data = mysqli_fetch_assoc($q);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Beli Produk - Snow Coffee</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1c1c1c; color: #f5f5f5; }
    .btn-beli { background-color: #6f4e37; border: none; }
    .btn-beli:hover { background-color: #8b5e3c; }
  </style>
</head>
<body>
<div class="container py-5">
  <h2>Beli Produk: <?= $data['nama_produk'] ?></h2>
  <p>Harga per cangkir: Rp <?= number_format($data['harga'], 0, ',', '.') ?></p>
  <p>Stok tersedia: <?= $data['stok'] ?></p>

  <form method="POST">
    <div class="mb-3">
      <label>Jumlah yang ingin dibeli</label>
      <input type="number" name="jumlah" class="form-control" min="1" max="<?= $data['stok'] ?>" required>
    </div>
    <button type="submit" name="beli" class="btn btn-beli">Konfirmasi Pembelian</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
  </form>

  <?php
  if (isset($_POST['beli'])) {
      $jumlah = $_POST['jumlah'];
      $total = $data['harga'] * $jumlah;
      $id_beli = "P" . rand(100, 999);
      $tanggal = date('Y-m-d H:i:s');

      if ($jumlah > $data['stok']) {
          echo "<script>alert('Stok tidak cukup!');</script>";
      } else {
          mysqli_query($koneksi, "INSERT INTO pembelian VALUES ('$id_beli', '$id', '$jumlah', '$total', '$tanggal')");
          mysqli_query($koneksi, "UPDATE produk SET stok = stok - $jumlah WHERE id_produk='$id'");
          echo "<script>alert('Pembelian berhasil! Total: Rp $total'); window.location='index.php';</script>";
      }
  }
  ?>
</div>
</body>
</html>
