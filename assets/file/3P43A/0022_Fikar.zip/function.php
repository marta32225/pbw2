<?php
$koreksi = mysqli_connect("localhost","root","","kelompok001");
// if($kifoneksi){
//     echo "behasil konek";
// }
if(isset($_POST['addnewmahasiswa'])){
    $nim_mahasiswa = $_POST['nim_mahasiswa'];
    $nama_mahasiswa = $_POST['nama_mahasiswa'];
    $alamat_mahasiswa = $_POST['alamat_mahasiswa'];
    $alamat_mahasiswa = $_POST['alamat_mahasiswa'];
    $jurusan_mahasiswa = $_POST['jurusan_mahasiswa'];

    $insert = mysqli_query($koneksi,"INSERT INTO mahasiswa (nim_mahasiswa, nama_mahasiswa, alamat_mahasiswa, jurusan_mahasiswa) VALUES ('$nim_mahasiswa','$nama_mahasiswa','$alamat_mahasiswa','$jurusan_mahasiswa') ");

    header('location:index.php');
}
if(isset($_POST['hapusnewmahasiswa'])){
    $id_mahasiswa = $_POST['id'];
    $insert = mysqli_query($koneksi,"DELETE FROM mahasiswa WHERE id_mhs='$id_mahasiswa' ");

    header('location:index.php');
}

if(isset($_POST['editnewmahasiswa'])){
    $nim_mahasiswa = $_POST['nim_mahasiswa'];
    $nama_mahasiswa = $_POST['nama_mahasiswa'];
    $alamat_mahasiswa = $_POST['alamat_mahasiswa'];
    $jurusan_mahasiswa = $_POST['jurusan_mahasiswa'];
    $id_mahasiswa = $_POST['id_mahasiswa'];

    $insert = mysqli_query($koneksi,"UPDATE mahasiswa SET nim_mahasiswa='$nim_mahasiswa', nama_mahasiswa='$nama_mahasiswa', alamat_mahasiswa='$alamat_mahasiswa', jurusan_mahasiswa='$jurusan_mahasiswa' WHERE id_mahasiswa='$id_mahasiswa' ");

    header('location:index.php');
}