<?php
include 'koneksi.php';
$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM menu WHERE id_menu='$id'");
echo "<script>alert('Data berhasil dihapus!');window.location='index.php';</script>";
?>
