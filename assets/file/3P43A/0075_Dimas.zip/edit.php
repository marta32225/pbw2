<?php
include 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM menu_makanan WHERE id='$id'");
$row = mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Menu</title>
</head>
<body>
<h2>Edit Menu</h2>
<form method="get" action="">
    <label>Nama Menu:</label><br>
    <input type="text" name="nama" value="<?php echo $row['nama']; ?>"><br><br>

    <label>Harga:</label><br>
    <input type="number" name="harga" value="<?php echo $row['harga']; ?>"><br><br>

    <label>Kategori:</label><br>
    <input type="text" name="kategori" value="<?php echo $row['kategori']; ?>"><br><br>

    <input type="submit" name="update" value="Update">
</form>

<?php
if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga_makanan'];
    $kategori = $_POST['kategori'];

    $query = "UPDATE menu SET nama='$nama', harga='$harga', kategori='$kategori'
              WHERE id='$id'";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Data berhasil diupdate!');window.location='index.php';</script>";
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>
</body>
</html>
