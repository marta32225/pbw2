-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2025 at 10:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_hp`
--

-- --------------------------------------------------------

--
-- Table structure for table `hp`
--

CREATE TABLE `hp` (
  `id` int(11) NOT NULL,
  `merk` varchar(50) DEFAULT NULL,
  `tipe` varchar(50) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `ram` varchar(10) DEFAULT NULL,
  `penyimpanan` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hp`
--

INSERT INTO `hp` (`id`, `merk`, `tipe`, `harga`, `ram`, `penyimpanan`) VALUES
(3, 'XIAOMI', 'REDMI NOTE 13 PRO+', 5400000, '12', '512'),
(4, 'SAMSUNG', 'GALAXY A55 5G', 5999000, '8', '256'),
(5, 'REALME', '11 PRO+ 5G', 6499000, '12', '512'),
(6, 'OPPO', 'RENO 11 F 5G', 4999000, '8', '256'),
(7, 'VIVO', 'V30 LITE 5G', 45999000, '8', '256'),
(8, 'IPHONE', '13 MINI', 10999000, '6', '128'),
(9, 'XIAOMI', 'POCO X6 PRO 5G', 4399000, '8', '256'),
(10, 'SAMSUNG', 'GALAXY S24 ULTRA', 21999000, '12', '512');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hp`
--
ALTER TABLE `hp`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hp`
--
ALTER TABLE `hp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
