<?php
include 'koreksi.php';

$nama_barang = $_POST['nama_barang'];
$jumlah = $_POST['jumlah'];
$harga = $_POST['hrg'];
$tanggal = $_POST['tgl'];

$sql = "INSERT INTO penjualan (nama, jumlah, harga, tanggal)
        VALUES ('$nm_barang', $jumlah, $harga, '$tanggal')";

if ($conn->query($sql) === TRUE) {
    header("Location: index.php");
} else {
    echo "Error: " . $conn->error;
}
?>