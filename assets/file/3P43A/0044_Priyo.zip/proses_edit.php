<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    echo "ID: " . $_GET['id'];
} else {
    echo "ID tidak ditemukan!";
}

$id = $_POST['id'];
$nama_barang = $_POST['nama_barang'];
$jumlah = $_POST['jumlah'];
$harga = $_POST['harga'];
$tanggal = $_POST['tanggal'];

$sql = "UPDATE penjualan
        SET nama_barang='$nama_barang', jumlah=$jumlah, harga=$harga, tanggal='$tanggal'
        WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: index.php");
} else {
    echo "Error: " . $conn->error;
}
?>