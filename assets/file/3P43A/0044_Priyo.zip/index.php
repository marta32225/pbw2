<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Penjualan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>CRUD Penjualan</h1>
    <form id="form-penjualan" action="tambah.php" method="GET">
        <label for="nama_barang">Nama Barang:</label>
        <input type="text" id="nama_barang" name="nm_barang" required>
        
        <label for="jumlah">Jumlah:</label>
        <input type="number" id="jumlah" name="jmlh" required>
        
        <label for="harga">Harga:</label>
        <input type="number" id="harga" name="harga" step="0.01" required>
        
        <label for="tanggal">Tanggal:</label>
        <input type="date" id="tanggal" name="tanggal" required>
        
        <button type="submit">Tambah</button>
    </form>
    
    <h2>Data Penjualan</h2>
    <table>
        <thead>
            <tr>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody id="data-penjualan">
        </tbody>
    </table>
    
    <script src="script.js"></script>
</body>
</html>