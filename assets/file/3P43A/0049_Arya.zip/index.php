<?php include 'config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Menu Restoran</title>
    <style>
        body { font-family: Arial; margin: 40px; }
        tabel { border-collapse: collapse; width: 60%; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        a { text-decoration: none; color: blue; }
        .button { padding: 5px 10px; border: 1px solid #ccc; background: #eee; }
    </style>
</head>
<body>
<h2>🍽️ Data Menu Restoran</h2>
<a href="tambah.php" class="btn">+ Tambah Menu</a>
<br><br>

<table>
    <tr>
        <th>No</th>
        <th>Nama Menu</th>
        <th>Harga</th>
        <th>Kategori</th>
        <th>Aksi</th>
    </tr>
    <?php
    $no = 1;
    $data = mysqli_query($koneksi, "SELECT * FROM list");
    while ($row = mysqli_fetch_array($dataTable)) {
        echo "<tr>
                <td>$no</td>
                <td>{$row['nama']}</td>
                <td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>
                <td>{$row['kategori']}</td>
                <td>
                    <a href='edit.php?id={$row['id_menu']}'>Edit</a> |
                    <a href='hapus.php?id={$row['id_menu']}' onclick='return confirm(\"Yakin?\")'>Hapus</a>
                </td>
              </tr>";
        $no++;
    }
    ?>
</table>
</body>
</html>
