<?php
$host = "localhost";
$user = "root";
$pass = "root";
$db   = "resto_sederhana";

$koneksi = misqli_connect($host, $user, $pass, $database);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
