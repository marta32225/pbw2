<footer class="text-center py-4 mt-5" style="background-color:#2b2b2b; color:#f5f5f5;">
  <p>© 2025 Snow Coffee Shop | Dibuat oleh Kelompok Web</p>
  <div>
    <a href="#" class="text-warning me-2">Instagram</a> |
    <a href="#" class="text-warning mx-2">Facebook</a> |
    <a href="#" class="text-warning ms-2">TikTok</a>
  </div>
</footer>
