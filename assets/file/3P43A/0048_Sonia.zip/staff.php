<?php
include 'con.php';
session_start();

// Cek apakah login sebagai staff
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Staff Only - Snow Coffee Shop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1c1c1c; color: #f5f5f5; }
    .card { background-color: #2b2b2b; border: none; }
    .button-update { background-color: #6f4e37; border: none; }
    .btn-ubah:hover { background-color: #8b5e3c; }
  </style>
</head>
<body>
<div class="container py-5">
  <h2 class="text-center mb-4">👨‍🍳 Staff Panel - Restok Barang</h2>

  <table class="table table-dark table-striped text-center">
    <thead>
      <tr>
        <th>ID Produk</th>
        <th>Nama Produk</th>
        <th>Stok</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $prdk = mysqli_query($koneksi, "SELECT * FROM produk_makanan");
      while ($p = mysqli_fetch_assoc($produk)) {
      ?>
        <tr>
          <td><?= $p['id'] ?></td>
          <td><?= $p['nama_produk'] ?></td>
          <td><?= $p['stok'] ?></td>
          <td>
            <a href="restok.php?id=<?= $p['id_produk'] ?>" class="btn btn-update btn-sm">Restok</a>
          </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>

  <a href="logout.php" class="btn btn-danger mt-3">Logout</a>
</div>
</body>
</html>
