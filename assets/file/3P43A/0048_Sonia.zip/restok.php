<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'staff') {
    echo "<h1 style='color:white;text-align:center;margin-top:100px;'>🚫 Hanya staf yang bisa mengakses halaman ini.</h1>";
    exit;
}

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $tambah = $_POST['tambah'];

    $query = "UPDATE produk SET stok = stok + $tambah WHERE id_produk='$id'";
    mysqli_query($koneksi, $query);
    echo "<script>alert('Stok berhasil ditambahkan!');window.location='restok.php';</script>";
}

$result = mysqli_query($koneksi, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Restok Barang</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1c1c1c; color: #fff; }
    .container { margin-top: 60px; }
    table { color: #fff; }
    .btn-coffee { background-color: #6f4e37; color: white; border: none; }
  </style>
</head>
<body>
<div class="container">
  <h2 class="mb-4">📦 Restok Barang</h2>
  <table class="table table-dark table-striped">
    <thead>
      <tr>
        <th>ID Produk</th>
        <th>Nama</th>
        <th>Stok Sekarang</th>
        <th>Tambah Stok</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
          <td><?= $row['id_produk'] ?></td>
          <td><?= $row['nama_produk'] ?></td>
          <td><?= $row['stok'] ?></td>
          <td>
            <form method="POST">
              <input type="hidden" name="id" value="<?= $row['id_produk'] ?>">
              <input type="number" name="tambah" min="1" class="form-control d-inline" style="width:100px;">
              <button type="submit" name="update" class="btn btn-coffee btn-sm">Tambah</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
