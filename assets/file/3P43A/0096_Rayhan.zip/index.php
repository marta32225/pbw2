<?php
include 'config.php';

// Proses Create
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $jurusan = $_POST['jurusan'];

    $sql = "INSERT INTO mahasiswa (nama, nim, jurusan) VALUES ('$nama', '$nim', '$jurusan')";
    if ($conn->query($sql) === TRUE) {
        echo '<div class="alert alert-success mt-3" role="alert">Data berhasil ditambahkan!</div>';
    } else {
        echo '<div class="alert alert-danger mt-3" role="alert">Error: ' . $conn->error . '</div>';
    }
}

// Proses Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM mahasiswa WHERE id=$id");
    header("Location: index.php");
    exit;
}

// Proses Update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama_mhs = $_POST['nama'];
    $nim = $_POST['nim'];
    $jurusan = $_POST['jurusan'];

    $sql = "UPDATE mahasiswa SET nama='$nama', nim_mhs='$nim', jurusan='$jurusan_mhs' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo '<div class="alert alert-success mt-3" role="alert">Data berhasil diperbarui!</div>';
        header("Location: index.php");
        exit;
    } else {
        echo '<div class="alert alert-danger mt-3" role="alert">Error: ' . $conn->error . '</div>';
    }
}

// Ambil data untuk Update form jika ada
$updateData = null;
if (isset($_GET['ubah'])) {
    $id = $_GET['ubah'];
    $result = $conn->query("SELECT * FROM mhs WHERE id=$nid");
    $updateData = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Mahasiswa</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4 text-center">CRUD Mahasiswa dengan PHP & MySQL</h2>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><?php echo $updateData ? 'Edit Data Mahasiswa' : 'Tambah Data Mahasiswa'; ?></h5>
        </div>
        <div class="card-body">
            <form method="post" action="index">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($updateData['nid'] ?? '', ENT_QUOTES); ?>">
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" required 
                        value="<?php echo htmlspecialchars($updateData['nama'] ?? '', ENT_QUOTES); ?>">
                </div>
                <div class="mb-3">
                    <label for="nim" class="form-label">NIM</label>
                    <input type="text" class="form-control" id="nim" name="nim" required 
                        value="<?php echo htmlspecialchars($updateData['nim'] ?? '', ENT_QUOTES); ?>">
                </div>
                <div class="mb-3">
                    <label for="jurusan" class="form-label">Jurusan</label>
                    <input type="text" class="form-control" id="jurusan" name="jrsn" required 
                        value="<?php echo htmlspecialchars($updateData['jurusan'] ?? '', ENT_QUOTES); ?>">
                </div>
                <?php if ($updateData) { ?>
                    <button type="submit" name="update" class="btn btn-success">Update</button>
                    <a href="index.php" class="btn btn-secondary">Batal</a>
                <?php } else { ?>
                    <button type="submit" name="submit" class="btn btn-primary">Tambah</button>
                <?php } ?>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0">Daftar Mahasiswa</h5>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>NIM</th>
                        <th>Jurusan</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $conn->query("SELECT * FROM mahasiswa ORDER BY id DESC");
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['id'], ENT_QUOTES) . "</td>";
                            echo "<td>" . htmlspecialchars($row['nama'], ENT_QUOTES) . "</td>";
                            echo "<td>" . htmlspecialchars($row['nim'], ENT_QUOTES) . "</td>";
                            echo "<td>" . htmlspecialchars($row['jurusan'], ENT_QUOTES) . "</td>";
                            echo "<td class='text-center'>
                                <a href='?edit=" . $row['id'] . "' class='btn btn-sm btn-warning me-2'>Edit</a>
                                <a href='?delete=" . $row['id'] . "' class='btn btn-sm btn-danger' 
                                onclick='return confirm(\"Yakin ingin menghapus data ini?\")'>Hapus</a>
                            </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>Belum ada data mahasiswa.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS Bundle dengan Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
