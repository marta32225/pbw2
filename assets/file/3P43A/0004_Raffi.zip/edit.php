<?php
include('config/koneksi.php');

$id = $_GET['id']; // Ambil ID dari URL

// 1. Ambil data lama untuk diisi ke form
$query_lama = mysqli_query($koneksi, "SELECT * FROM mahasiswa WHERE id='$id'");
$data_lama  = mysqli_fetch_array($query_lama);

// Bagian proses UPDATE data (CP: CRUD sederhana)
if (isset($_POST['update'])) {
    $nim_baru     = mysqli_real_escape_string($koneksi, $_POST['nim']);
    $nama_baru    = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $jurusan_baru = mysqli_real_escape_string($koneksi, $_POST['jurusan']);
    $alamat_baru  = mysqli_real_escape_string($koneksi, $_POST['alamat']);

    // Validasi Sederhana
    if (empty($nim_baru) || empty($nama_baru) || empty($jurusan_baru)) {
        $pesan_error = "Semua field wajib diisi!";
    } else {
        // Query UPDATE data
        $sql = "UPDATE mahasiswa SET nim='$nim_baru', nama='$nama_baru', jurusan='$jurusan_baru', alamat='$alamat_baru' WHERE id='$id'";
        $update = mysqli_query($koneksi, $sql);

        if ($update) {
            header("location:index.php"); // Redirect ke halaman utama
            exit();
        } else {
            $pesan_error = "Gagal mengupdate data: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Mahasiswa - CRUD PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">✏️ Edit Data Mahasiswa</h2>
    <div class="card p-4">
        
        <?php if (isset($pesan_error)) { echo '<div class="alert alert-danger">'.$pesan_error.'</div>'; } ?>

        <form method="POST">
            <div class="mb-3">
                <label for="nim" class="form-label">NIM</label>
                <input type="text" class="form-control" id="nim" name="nim" value="<?php echo htmlspecialchars($data_lama['nim']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo htmlspecialchars($data_lama['nama']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="jurusan" class="form-label">Jurusan</label>
                <select class="form-select" id="jurusan" name="jurusan" required>
                    <?php 
                    $pilihan_jurusan = ['Teknik Informatika', 'Sistem Informasi', 'Konputerisasi akutansi'];
                    foreach ($pilihan_jurusan as $jrs) {
                        $selected = ($jrs == $data_lama['jurusan']) ? 'selected' : '';
                        echo "<option value='{$jrs}' {$selected}>{$jrs}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat"><?php echo htmlspecialchars($data_lama['alamat']); ?></textarea>
            </div>
            
            <button type="submit" name="update" class="btn btn-warning">Update Data</button>
            <a href="index.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>
</body>
</html>