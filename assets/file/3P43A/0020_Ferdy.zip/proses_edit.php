<?php
include 'koreksi.php';

if (isset($_POST['id'])) {
    echo "ID: " . $_POST['id'];
} else {
    echo "ID tidak ditemukan!";
}

$id = $_POST['nid'];
$nama_barang = $_POST['nm_barang'];
$jumlah = $_POST['jumlah'];
$harga = $_POST['harga'];
$tanggal = $_POST['tanggal'];

$sql = "UPDATE penjualan
        SET nama_barang='$nama_barang', jmlh=$jumlah, hrg=$harga, tanggal='$tgl'
        WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: index.php");
} else {
    echo "Error: " . $conn->error;
}
?>