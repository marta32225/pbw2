<?php
include 'koneksi.php';

$nama_barang = $_POST['nama_barang'];
$jumlah = $_POST['jumlah'];
$harga = $_POST['harga'];
$tanggal = $_POST['tanggal'];

$sql = "INSERT INTO penjualan (nama_barang, jumlah, harga, tanggal)
        VALUES ('$nama_barang', $jumlah, $harga, '$tanggal')";

if ($conn->query($sql) === TRUE) {
    header("Location: index.php");
} else {
    echo "Error: " . $conn->error;
}
?>