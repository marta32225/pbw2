<?php
include 'koneksi.php';

$id = $_POST['id'];

$sql = "SELECT * FROM penjualan WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $rows = $result->fetch_assoc();
} else {
    die("Data tidak ditemukan");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Penjualan</title>
    <link rel="stylesheet" href="edit.css">
</head>
<body>
    <h1>Edit Data Penjualan</h1>
    <form action="proses_edit.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['nid']; ?>">
        
        <label for="nama_barang">Nama Barang:</label>
        <input type="text" id="nama_barang" name="nama_barang" value="<?php echo $rows['nama_barang']; ?>" required>
        
        <label for="jumlah">Jumlah:</label>
        <input type="number" id="jumlah" name="jumlah" value="<?php echo $row['jmlh']; ?>" min="1" required>
        
        <label for="harga">Harga:</label>
        <input type="number" id="harga" name="harga" value="<?php echo $rows['harga']; ?>" step="0.01" required>
        
        <label for="tanggal">Tanggal:</label>
        <input type="date" id="tanggal" name="tanggal" value="<?php echo $row['tgl']; ?>" required>
        
        <button type="submit">Simpan</button>
    </form>
</body>
</html>