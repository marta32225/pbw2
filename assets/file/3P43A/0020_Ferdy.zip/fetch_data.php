<?php
include 'koneksi.php';

$sql = "SELECT * FROM penjualan";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['nama_barang']}</td>
                <td>{$row['jumlah']}</td>
                <td>{$row['harga']}</td>
                <td>{$row['tanggal']}</td>
                <td>
                    <a href='edit.php?id={$row['id']}'>Edit</a> |
                    <a href='hapus.php?id={$row['id']}' onclick='return confirm(\"Yakin ingin menghapus?\");'>Hapus</a>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>Tidak ada data</td></tr>";
}
?>