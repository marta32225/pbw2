<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "crud_pnjln"; // harus sama dengan database yang kamu buat

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>