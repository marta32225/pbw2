<?php
include 'koneksi.php';

$id = $_POST['nid'];

$sql = "DELETE FROM penjualan WHERE nid=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: index.php");
} else {
    echo "Error: " . $conn->error;
}
?>