<?php
// Pengaturan Koneksi
$host = "localhost";
$user = "root";     // Sesuaikan dengan user MySQL Anda
$pass = "";         // Sesuaikan dengan password MySQL Anda
$db   = "db_kampus"; // Nama database yang sudah dibuat

// Membuat Koneksi
$koneksi = mysqli_connect($host, $user, $pass, $db);

// Cek Koneksi
if (mysqli_connect_errno()) {
    // Menampilkan pesan error jika koneksi gagal (CP: sintaks PHP)
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>