<?php
include('config/koneksi.php');

// Bagian proses CREATE data (CP: CRUD sederhana)
if (isset($_POST['submit'])) {
    $nim     = mysqli_real_escape_string($koneksi, $_POST['nim']);
    $nama    = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $jurusan = mysqli_real_escape_string($koneksi, $_POST['jurusan']);
    $alamat  = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    
    // Validasi Sederhana (CP: membuat form dinamis dengan validasi sederhana)
    if (empty($nim) || empty($nama) || empty($jurusan)) {
        $pesan_error = "Semua field wajib diisi!";
    } else {
        // Query INSERT data
        $sql = "INSERT INTO mahasiswa (nim, nama, jurusan, alamat) VALUES ('$nim', '$nama', '$jurusan', '$alamat')";
        $insert = mysqli_query($koneksi, $sql);

        if ($insert) {
            header("location:index.php"); // Redirect ke halaman utama
            exit();
        } else {
            $pesan_error = "Gagal menyimpan data: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Mahasiswa - CRUD PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4">➕ Tambah Data Mahasiswa</h2>
    <div class="card p-4">
        
        <?php if (isset($pesan_error)) { echo '<div class="alert alert-danger">'.$pesan_error.'</div>'; } ?>

        <form method="POST">
            <div class="mb-3">
                <label for="nim" class="form-label">NIM</label>
                <input type="text" class="form-control" id="nim" name="nim" required>
            </div>
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="mb-3">
                <label for="jurusan" class="form-label">Jurusan</label>
                <select class="form-select" id="jurusan" name="jurusan" required>
                    <option value="Teknik Informatika">S1 Teknik Informatika</option>
                    <option value="Sistem Informasi">S1 Sistem Informasi</option>
                    <option value="Konputerisasi akutansi">D3 Konputerisasi akutansi</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat"></textarea>
            </div>
            
            <button type="submit" name="submit" class="btn btn-success">Simpan Data</button>
            <a href="index.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>
</body>
</html>