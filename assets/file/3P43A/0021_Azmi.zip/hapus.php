<?php
include('config/koneksi.php');

// Bagian proses DELETE data (CP: CRUD sederhana)
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Query DELETE data
    $delete = mysqli_query($koneksi, "DELETE FROM mahasiswa WHERE id='$id'");

    if ($delete) {
        // Redirect setelah berhasil
        header("location:index.php");
        exit();
    } else {
        echo "Gagal menghapus data: " . mysqli_error($koneksi);
        // Tambahkan tombol kembali jika gagal
        echo "<br><a href='index.php'>Kembali</a>";
    }
} else {
    // Jika tidak ada ID yang diberikan
    header("location:index.php");
    exit();
}
?>