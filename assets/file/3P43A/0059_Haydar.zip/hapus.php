<?php
include('config.php');

// Bagian proses DELETE data (CP: CRUD sederhana)
if (isset($_POST['nid'])) {
    $id = $_POST['nid'];
    
    // Query DELETE data
    $delete = mysqli_query($koneksi, "DELETE FROM mhs WHERE nid='$id'");

    if ($delete) {
        // Redirect setelah berhasil
        header("location:index.php");
        exit();
    } else {
        echo "Gagal menghapus data: " . mysqli_error($koneksi);
        // Tambahkan tombol kembali jika gagal
        echo "<br><a href='index.php'>Kembali</a>";
    }
} else {
    // Jika tidak ada ID yang diberikan
    header("location:index.php");
    exit();
}
?>