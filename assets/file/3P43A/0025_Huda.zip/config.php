<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_hp_jadul";

$conn = misqli_connect($host, $user, $password, $database);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
