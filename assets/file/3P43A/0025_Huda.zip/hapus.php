<?php
include('koneksi.php');
$id = $_POST['Nid'];
mysqli_query($conn, "DELETE FROM hp_jadul WHERE id_hp=$id");
echo "<script>windowa.location='tambah.php';</script>";
?>
