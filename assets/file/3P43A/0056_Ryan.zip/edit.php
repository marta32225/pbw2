<?php 
include('config.php');
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM hp WHERE id=$id"));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data HP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f2f4f8; font-family: Arial; }
        .container { background: #fff; padding: 30px; border-radius: 10px; margin-top: 40px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #333; }
    </style>
</head>
<body>
<div class="container">
    <h2>Edit Data Handphone</h2>
    <form method="post">
        <div class="mb-3">
            <label>Merk</label>
            <input type="text" name="merk" value="<?= $data['merk'] ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Tipe</label>
            <input type="text" name="tipe" value="<?= $data['tipe'] ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="harga" value="<?= $data['harga'] ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>RAM</label>
            <input type="text" name="ram" value="<?= $data['ram'] ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Penyimpanan</label>
            <input type="text" name="penyimpanan" value="<?= $data['penyimpanan'] ?>" class="form-control" required>
        </div>
        <button type="submit" name="update" class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>

    <?php
    if (isset($_POST['update'])) {
        $merk = $_POST['merk'];
        $tipe = $_POST['tipe'];
        $harga = $_POST['harga'];
        $ram = $_POST['ram'];
        $penyimpanan = $_POST['penyimpanan'];

        mysqli_query($conn, "UPDATE hp SET merk='$merk', tipe='$tipe', harga='$harga', ram='$ram', penyimpanan='$penyimpanan' WHERE id=$id");
        echo "<script>window.location='index.php';</script>";
    }
    ?>
</div>
</body>
</html>
