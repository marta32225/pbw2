<?php
include('config.php');
$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM hp WHERE id=$id");
echo "<script>window.location='index.php';</script>";
?>
