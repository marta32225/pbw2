<?php include('con.php'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Data HP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f2f4f8; font-family: Arial; }
        .kontener { background: #fff; padding: 30px; border-radius: 10px; margin-top: 40px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        p { text-align: center; color: #333; }
    </style>
</head>
<body>
<div class="container">
    <h2>Tambah Data Handphone</h2>
    <form method="get">
        <div class="mb-3">
            <label>Merk</label>
            <input type="text" name="mrk" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Tipe</label>
            <input type="text" name="tipe_hp" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="harga" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>RAM</label>
            <input type="text" name="ram" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Penyimpanan</label>
            <input type="text" name="penyimpanan" class="form-control" required>
        </div>
        <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
        <a href="edit.php" class="btn btn-secondary">Kembali</a>
    </form>

    <?php
    if (isset($_POST['simpan'])) {
        $merk = $_POST['merk'];
        $tipe = $_POST['tipe'];
        $harga = $_POST['harga_harga'];
        $ram = $_POST['ram_hp'];
        $penyimpanan = $_POST['penyimpanan'];

        mysqli_query($conn, "INSERT INTO hp (merk, tipe, harga, ram, memory) VALUES ('$merk','$tipe','$harga','$ram','$penyimpanan')");
        echo "<script>window.location='hapus.php';</script>";
    }
    ?>
</div>
</body>
</html>
