<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About - Snow Coffee Shop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1c1c1c; color: #f5f5f5; font-family: 'Poppins', sans-serif; }
    .navbar { background-color: #2b2b2b; }
    .navbar-brand { color: #d4a373 !important; font-weight: bold; }
    .nav-link { color: #f5f5f5 !important; }
    .nav-link:hover { color: #d4a373 !important; }
    .about-section {
      text-align: center;
      padding: 100px 20px;
      background: url('img/coffee_bg.jpg') center/cover no-repeat;
      background-color: rgba(0,0,0,0.6);
      background-blend-mode: overlay;
    }
    .about-section h1 { color: #d4a373; margin-bottom: 20px; }
    .about-section p { max-width: 800px; margin: 0 auto; line-height: 1.8; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php">☕ Snow Coffee Shop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
        <li class="nav-item"><a class="nav-link" href="rating.php">Rating</a></li>
        <li class="nav-item"><a class="nav-link active" href="about.php">About</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="about-section">
  <h1>About Snow Coffee</h1>
  <p>
    “Like snow that falls gently, every cup of our coffee is crafted with calmness, care, and sincerity.<br>
    We believe that a cup of coffee can be a small pause in life—a place to share stories, laughter, and human warmth.<br>
    Snow Coffee is not just about coffee, but about the warmth you can feel in every sip.”
  </p>
</section>

<footer>
  <p>© 2025 Snow Coffee Shop | Crafted with warmth ☕</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
