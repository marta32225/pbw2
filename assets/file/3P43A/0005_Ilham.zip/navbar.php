<ul class="navbar-nav ms-auto">
  <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
  <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
  <li class="nav-item"><a class="nav-link" href="rating.php">Rating</a></li>

  <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'staff'): ?>
      <li class="nav-item"><a class="nav-link" href="restok.php">Staff Only</a></li>
  <?php endif; ?>

  <?php if(isset($_SESSION['username'])): ?>
      <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
  <?php else: ?>
      <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
  <?php endif; ?>
</ul>
