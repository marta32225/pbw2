<?php
include 'koneksi.php';
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Beri Rating - Snow Coffee Shop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1c1c1c; color: #f5f5f5; font-family: 'Poppins', sans-serif; }
    .navbar { background-color: #2b2b2b; }
    .navbar-brand { color: #d4a373 !important; font-weight: bold; }
    .nav-link { color: #f5f5f5 !important; }
    .nav-link:hover { color: #d4a373 !important; }
    h2 { color: #d4a373; }

    .star { font-size: 28px; color: #ffd700; cursor: pointer; }
    .form-box { background-color: #2b2b2b; padding: 30px; border-radius: 15px; box-shadow: 0 0 15px rgba(0,0,0,0.4); }
    footer { background-color: #2b2b2b; color: #f5f5f5; padding: 20px 0; text-align: center; margin-top: 40px; }
  </style>
  <script>
    function pilihRating(nilai) {
      document.getElementById('bintang').value = nilai;
      const stars = document.querySelectorAll('.star');
      stars.forEach((s, i) => {
        s.textContent = i < nilai ? '★' : '☆';
      });
    }
  </script>
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php">☕ Snow Coffee Shop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
        <li class="nav-item"><a class="nav-link active" href="rating.php">Rating</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'staff'): ?>
          <li class="nav-item"><a class="nav-link" href="restok.php">Staff Only</a></li>
        <?php endif; ?>

        <?php if (isset($_SESSION['username'])): ?>
          <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!--  Form Rating -->
<div class="container py-5">
  <h2 class="text-center mb-4">Give Your Rating</h2>
  <div class="form-box mx-auto" style="max-width: 600px;">
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="nama" class="form-control" required>
      </div>

      <div class="mb-3 text-center">
        <label class="d-block mb-2">Select Rating:</label>
        <span class="star" onclick="pilihRating(1)">☆</span>
        <span class="star" onclick="pilihRating(2)">☆</span>
        <span class="star" onclick="pilihRating(3)">☆</span>
        <span class="star" onclick="pilihRating(4)">☆</span>
        <span class="star" onclick="pilihRating(5)">☆</span>
        <input type="hidden" id="bintang" name="bintang" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Comment</label>
        <textarea name="komentar" class="form-control"></textarea>
      </div>

      <button type="submit" name="kirim" class="btn btn-warning w-100">Submit Rating</button>
    </form>
  </div>

  <?php
  if (isset($_POST['kirim'])) {
      $id = "R" . rand(100, 999);
      $nama = $_POST['nama'];
      $bintang = $_POST['bintang'];
      $komentar = $_POST['komentar'];

      mysqli_query($koneksi, "INSERT INTO rating VALUES ('$id', '$nama', '$bintang', '$komentar')");
      echo "<script>alert('Thank you for your rating!'); window.location='index.php';</script>";
  }
  ?>
</div>

<!--  Footer -->
<footer>
  <p>© 2025 Snow Coffee Shop | Every sip brings warmth ☕</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
