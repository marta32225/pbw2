<?php
include 'koneksi.php';
session_start();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Snow Coffee Shop</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #1c1c1c; color: #f5f5f5; font-family: 'Poppins', sans-serif; }
    .navbar { background-color: #2b2b2b; }
    .navbar-brand { color: #d4a373 !important; font-weight: bold; }
    .nav-link { color: #f5f5f5 !important; }
    .nav-link:hover { color: #d4a373 !important; }
    .hero {
      background: url('img/background.jpg') center/cover no-repeat;
      height: 90vh;
      display: flex; flex-direction: column;
      justify-content: center; align-items: center;
      text-align: center;
      background-color: rgba(0,0,0,0.5);
      background-blend-mode: overlay;
    }
    .hero h1 { font-size: 3rem; color: #d4a373; }
    .btn-coffee { background-color: #6f4e37; border: none; color: white; padding: 12px 24px; }
    .btn-coffee:hover { background-color: #8b5e3c; }
    footer { background-color: #2b2b2b; color: #f5f5f5; padding: 20px 0; text-align: center; }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="index.php">☕ Snow Coffee Shop</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
        <li class="nav-item"><a class="nav-link" href="rating.php">Rating</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'staff'): ?>
          <li class="nav-item"><a class="nav-link" href="restok.php">Staff Only</a></li>
        <?php endif; ?>

        <?php if (isset($_SESSION['username'])): ?>
          <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero">
  <h1>Selamat Datang di Snow Coffee Shop</h1>
  <p>Temukan rasa kopi terbaik dari biji pilihan dunia</p>
  <a href="menu.php" class="btn btn-coffee mt-3">☕ Lihat Menu</a>
</section>

<footer>
  <p>© 2025 Snow Coffee Shop | Nikmati kopi, nikmati hidup ☕</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
