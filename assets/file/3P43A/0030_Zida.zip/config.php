<?php
$host = "localhost";  // sesuaikan dengan server hosting
$username = "root";   // username database Anda
$password = "";       // password database Anda
$database = "tugas_crud";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>