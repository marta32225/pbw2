<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Registration Page</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?=base_url();?>/assets/vendor/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?=base_url();?>/assets/vendor/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url();?>/assets/vendor/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition register-page">
<div class="register-box">
  <div class="register-logo">
    <a href="../../index2.html"><b>Admin</b>LTE</a>
  </div>

  <div class="card">
    <div class="card-body register-card-body">
      <!-- Judul -->
      <p class="login-box-msg"><?= $judul_form ?></p>
      <!-- Judul -->
      <!-- Form -->
      <?php 
        echo form_open_multipart('Login');
        $inputs = session()->getFlashdata('inputs');
        $errors = session()->getFlashdata('errors');
        if(!empty($errors)){?>
          <div class="alert alert-danger" role="alert">
            Ada kesalahan input data, yaitu :
            <ul>
              <?php foreach($errors as $error) : ?>
                <li><?= esc($error) ?></li>
              <?php endforeach ?>
            </ul>
          </div>
        <?php
        }
      ?>
        <!-- Field Username User -->
        <div class="form-group input-group">
          <?php
          $data = [
            'name'        => 'username',
            'id'          => 'username',
            'placeholder' => 'Masukan Username',
            'class'       => 'form-control'
          ];
          echo form_input($data);
          ?>
          <div class="input-group-prepend">
            <span class="input-group-text">
              <i class="fas fa-user"></i>
            </span>
          </div>
        </div>
        <!-- Field Username User -->
        <!-- Field Paassword User -->
        <div class="form-group input-group">
          <?php
          $data = [
            'name'        => 'password',
            'id'          => 'password',
            'placeholder' => 'Masukan Password',
            'class'       => 'form-control',
            'type'        => 'password'
          ];
          echo form_input($data);
          ?>
          <div class="input-group-prepend">
            <span class="input-group-text">
              <i class="fas fa-lock"></i>
            </span>
          </div>
        </div>
        <!-- Field Password User -->
        <!-- Tombol Login -->
        <div class="row">
            <button type="submit" class="btn btn-primary btn-block">Login</button>
        </div>
        <!-- Tombol Login -->
      <?php echo form_close(); ?>
      <!-- Form -->

    </div>
    <!-- /.form-box -->
  </div><!-- /.card -->
</div>
<!-- /.register-box -->

<!-- jQuery -->
<script src="<?=base_url();?>/assets/vendor/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?=base_url();?>/assets/vendor/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url();?>/assets/vendor/dist/js/adminlte.min.js"></script>
</body>
</html>
